package test2;

import MainProgram.AppUtilities;
import com.formdev.flatlaf.FlatClientProperties;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.RoundRectangle2D;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JComboBox;


public class AddItemPopup extends javax.swing.JPanel {

    public AddItemPopup() throws IOException {
        initComponents();
        setOpaque(false);
        
        //Instance AppUtilities (Singleton Code)
        AppUtilities utilities = new AppUtilities();
        
        //FontStyle
        utilities.customFontStyle(headerTxtPanel, "Poppins-Bold.ttf", 18f);
        utilities.customFontStyle(addBtn, "Poppins-Regular.ttf", 16f);
        
        //Placeholder
        initializePlaceholders();
        utilities.customFontStyle(txtEquipID, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(txtEquipName, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(txtEquipType, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(txtEquipQnty, "Poppins-Regular.ttf", 16f);
    }
    
    //Round Corner Panel
    @Override
    protected void paintComponent(Graphics grphcs) {
        Graphics2D g2 = (Graphics2D) grphcs.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getBackground());
//        AffineTransform trans = new AffineTransform();
//        trans.translate(getWidth() - 25, 5);
        g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 15, 15));
        g2.dispose();
        super.paintComponent(grphcs);
    }
    
    public void setHoverBtn(JButton button, String hoverColor) {
        button.setBackground(Color.decode(hoverColor));
    }

    // Reset Hover Menu Button
    public void resetHoverBtn(JButton button, String defaultColor) {
        button.setBackground(Color.decode(defaultColor));
    }
    
    //Placeholder Method
    private void initializePlaceholders() {
        txtEquipID.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Equipment ID");
        txtEquipName.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Name of Equipment");
//        txtEquipType.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Equipment Type");
//        txtEquipQnty.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Quantity");

//        setupComboBoxPlaceholder(txtEquipType, "Select Equipment Type");
//        setupComboBoxPlaceholder(txtEquipQnty, "Select Quantity");
    }
    
//    private void setupComboBoxPlaceholder(JComboBox<String> comboBox, String placeholder) {
//        comboBox.insertItemAt(placeholder, 0); // Add placeholder at the first position
//        comboBox.setSelectedIndex(0); // Set placeholder as default
//        comboBox.setForeground(Color.GRAY); // Set placeholder color
//
//        comboBox.addActionListener(e -> {
//            if (comboBox.getSelectedIndex() != 0) {
//                comboBox.setForeground(Color.BLACK); // Change to normal color on valid selection
//            } else {
//                comboBox.setForeground(Color.GRAY); // Keep gray for the placeholder
//            }
//        });
//    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        addItemPanel = new javax.swing.JPanel();
        headerTxtPanel = new javax.swing.JLabel();
        addBtn = new MainProgram.Button();
        txtEquipID = new javax.swing.JTextField();
        txtEquipName = new javax.swing.JTextField();
        txtEquipType = new javax.swing.JComboBox<>();
        txtEquipQnty = new javax.swing.JComboBox<>();

        mainPanel.setBackground(new java.awt.Color(255, 255, 255));

        addItemPanel.setBackground(new java.awt.Color(8, 194, 255));

        headerTxtPanel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        headerTxtPanel.setForeground(new java.awt.Color(255, 255, 255));
        headerTxtPanel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/plus.png"))); // NOI18N
        headerTxtPanel.setText("Add Equipment to Inventory");

        javax.swing.GroupLayout addItemPanelLayout = new javax.swing.GroupLayout(addItemPanel);
        addItemPanel.setLayout(addItemPanelLayout);
        addItemPanelLayout.setHorizontalGroup(
            addItemPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addItemPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(headerTxtPanel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        addItemPanelLayout.setVerticalGroup(
            addItemPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addItemPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(headerTxtPanel)
                .addContainerGap())
        );

        addBtn.setBackground(new java.awt.Color(13, 110, 244));
        addBtn.setForeground(new java.awt.Color(255, 255, 255));
        addBtn.setText("ADD");
        addBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                addBtnMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                addBtnMouseReleased(evt);
            }
        });
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });

        txtEquipID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEquipIDActionPerformed(evt);
            }
        });

        txtEquipType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Balls", "Rackets or Bats", "Protective Gear", "Nets or Goals" }));

        txtEquipQnty.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        txtEquipQnty.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(addItemPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(txtEquipName, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtEquipType, javax.swing.GroupLayout.Alignment.LEADING, 0, 323, Short.MAX_VALUE)
                    .addComponent(txtEquipQnty, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtEquipID))
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addComponent(addItemPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(txtEquipID, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(txtEquipName, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(txtEquipType, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(txtEquipQnty, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        
    }//GEN-LAST:event_addBtnActionPerformed

    private void addBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addBtnMousePressed
        setHoverBtn(addBtn, "#0B5CC9");  
    }//GEN-LAST:event_addBtnMousePressed

    private void addBtnMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addBtnMouseReleased
        resetHoverBtn(addBtn, "#0D6EF4");
    }//GEN-LAST:event_addBtnMouseReleased

    private void txtEquipIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEquipIDActionPerformed
        txtEquipID.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Equipment ID");
    }//GEN-LAST:event_txtEquipIDActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private MainProgram.Button addBtn;
    private javax.swing.JPanel addItemPanel;
    private javax.swing.JLabel headerTxtPanel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JTextField txtEquipID;
    private javax.swing.JTextField txtEquipName;
    private javax.swing.JComboBox<String> txtEquipQnty;
    private javax.swing.JComboBox<String> txtEquipType;
    // End of variables declaration//GEN-END:variables
}
