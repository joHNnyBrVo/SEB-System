package ReportGenerator;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PDFGenerator {
    private static final String REPORTS_DIR = "D:\\Documents\\NetBeansProjects\\SEB_System\\reports\\";

    public static void generateFromTable(JTable table, String baseFileName, JFrame parentFrame) throws IOException {
        File reportsDir = new File(REPORTS_DIR);
        if (!reportsDir.exists()) {
            reportsDir.mkdirs();
        }

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String defaultFileName = baseFileName + "_" + timestamp + ".pdf";

        JFileChooser fileChooser = new JFileChooser(REPORTS_DIR);
        fileChooser.setDialogTitle("Save PDF Report");
        fileChooser.setSelectedFile(new File(defaultFileName));
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("PDF Files (*.pdf)", "pdf"));

        parentFrame.setIconImage(new ImageIcon(PDFGenerator.class.getResource("/icons/SEB_System.png")).getImage());

        int userSelection = fileChooser.showSaveDialog(parentFrame);
        
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            if (!fileToSave.getName().toLowerCase().endsWith(".pdf")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".pdf");
            }

            if (fileToSave.exists()) {
                int response = JOptionPane.showConfirmDialog(parentFrame,
                        "The file already exists. Do you want to replace it?",
                        "Confirm Overwrite",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);
                
                if (response != JOptionPane.YES_OPTION) {
                    return;
                }
            }

            Document document = new Document(PageSize.A4.rotate());
            try {
                PdfWriter.getInstance(document, new FileOutputStream(fileToSave));
                document.open();
                
                Font titleFont = FontFactory.getFont("Arial", 18, Font.BOLD);
                Font headerFont = FontFactory.getFont("Arial", 10, Font.BOLD);
                Font dataFont = FontFactory.getFont("Arial", 10, Font.NORMAL);
                
                Paragraph title = new Paragraph(baseFileName, titleFont);
                title.setAlignment(Element.ALIGN_CENTER);
                title.setSpacingAfter(20);
                document.add(title);
                
                PdfPTable pdfTable = new PdfPTable(table.getColumnCount());
                pdfTable.setWidthPercentage(100);
                
                pdfTable.setSplitRows(true);
                pdfTable.setSplitLate(false);
                
                for (int i = 0; i < table.getColumnCount(); i++) {
                    PdfPCell cell = new PdfPCell(new Phrase(table.getColumnName(i), headerFont));
                    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                    cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                    cell.setBackgroundColor(new BaseColor(240, 240, 240));
                    cell.setPadding(5);
                    pdfTable.addCell(cell);
                }
                
                for (int i = 0; i < table.getRowCount(); i++) {
                    for (int j = 0; j < table.getColumnCount(); j++) {
                        Object value = table.getValueAt(i, j);
                        PdfPCell cell = new PdfPCell(new Phrase(value != null ? value.toString() : "", dataFont));
                        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                        cell.setPadding(5);
                        pdfTable.addCell(cell);
                    }
                }
                
                document.add(pdfTable);
                
                JOptionPane.showMessageDialog(parentFrame, 
                    "PDF file generated successfully!", 
                    "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                
            } catch (DocumentException e) {
                throw new IOException(e);
            } finally {
                document.close();
            }
        }
    }
}