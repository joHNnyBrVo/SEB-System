package ReportGenerator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;
import javax.swing.table.TableModel;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CSVGenerator {
    private static final String REPORTS_DIR = "D:\\Documents\\NetBeansProjects\\SEB_System\\reports\\";

    public static void generateFromTable(JTable table, String baseFileName, JFrame parentFrame) throws IOException {
        File reportsDir = new File(REPORTS_DIR);
        if (!reportsDir.exists()) {
            reportsDir.mkdirs();
        }

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String defaultFileName = baseFileName + "_" + timestamp + ".csv";

        JFileChooser fileChooser = new JFileChooser(REPORTS_DIR);
        fileChooser.setDialogTitle("Save CSV Report");
        fileChooser.setSelectedFile(new File(defaultFileName));
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("CSV Files (*.csv)", "csv"));

        // Set the icon for the parent frame
        parentFrame.setIconImage(new ImageIcon(CSVGenerator.class.getResource("/icons/SEB_System.png")).getImage());

        int userSelection = fileChooser.showSaveDialog(parentFrame);
        
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            if (!fileToSave.getName().toLowerCase().endsWith(".csv")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".csv");
            }

            if (fileToSave.exists()) {
                int response = JOptionPane.showConfirmDialog(parentFrame,
                        "The file already exists. Do you want to replace it?",
                        "Confirm Overwrite",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);
                
                if (response != JOptionPane.YES_OPTION) {
                    return;
                }
            }

            try (FileWriter csv = new FileWriter(fileToSave)) {
                TableModel model = table.getModel();
                
                for (int i = 0; i < model.getColumnCount(); i++) {
                    csv.write(model.getColumnName(i));
                    if (i < model.getColumnCount() - 1) {
                        csv.write(",");
                    }
                }
                csv.write("\n");
                
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        Object value = model.getValueAt(i, j);
                        csv.write(value != null ? value.toString() : "");
                        if (j < model.getColumnCount() - 1) {
                            csv.write(",");
                        }
                    }
                    csv.write("\n");
                }
                
                JOptionPane.showMessageDialog(parentFrame, 
                    "CSV file generated successfully!", 
                    "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
}