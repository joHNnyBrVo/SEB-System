package test2;
import Database.dbConnection;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import raven.cell.TableActionCellEditor;
import raven.cell.TableActionCellRender;
import raven.cell.TableActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class table extends javax.swing.JFrame {
    private Connection conn;
    public table() {
        initComponents();
        dbConnection db = new dbConnection();
        
        try {
            conn = db.createConnection();
        } catch (SQLException ex) {
            Logger.getLogger(PopupModal.AddItemPopup.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PopupModal.AddItemPopup.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        displayInventory(); 
        
        TableActionEvent event = new TableActionEvent() {
            @Override
            public void onEdit(int row) {
                DefaultTableModel model = (DefaultTableModel) inventoryTable.getModel(); 
                String equipmentID = model.getValueAt(row, 1).toString(); 
                String equipmentName = model.getValueAt(row, 2).toString(); 
                String equipmentType = model.getValueAt(row, 3).toString(); 
                String equipmentQuantity = model.getValueAt(row, 4).toString();

                try {
                    editInventoryPopup popup = new editInventoryPopup(null, true);
                    popup.setFields(equipmentID, equipmentName, equipmentType, equipmentQuantity); 
                    popup.setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(table.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            @Override
            public void onDelete(int row) {
                if (inventoryTable.isEditing()) {
                    inventoryTable.getCellEditor().stopCellEditing();
                }

                int id = (int) inventoryTable.getValueAt(row, 0);  

                if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this item?", "Confirm Delete", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    try (PreparedStatement pstmt = conn.prepareStatement("DELETE FROM inventory WHERE id = ?")) {
                        pstmt.setInt(1, id);
                        if (pstmt.executeUpdate() > 0) {
                            ((DefaultTableModel) inventoryTable.getModel()).removeRow(row); 
                            JOptionPane.showMessageDialog(null, "Item deleted successfully.");
                        } else {
                            JOptionPane.showMessageDialog(null, "Error: Unable to delete item.", "Database Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }

            @Override
            public void onView(int row) {
                try {
                    //                System.out.println("View row : " + row);
                    BorrowPopup popup = new BorrowPopup(null, true);
                    popup.setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(table.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };
        inventoryTable.getColumnModel().getColumn(5).setCellRenderer(new TableActionCellRender());
        inventoryTable.getColumnModel().getColumn(5).setCellEditor(new TableActionCellEditor(event));
    }
    
        public void displayInventory(){
            String query = "SELECT id, equipmentID, equipmentName, type, quantity FROM inventory";
    
            try (PreparedStatement pstmt = conn.prepareStatement(query);
                 ResultSet rs = pstmt.executeQuery()) {

                DefaultTableModel model = (DefaultTableModel) inventoryTable.getModel();
                model.setRowCount(0);

                while (rs.next()) {
                    int id = rs.getInt("id");
                    String equipmentID = rs.getString("equipmentID");
                    String equipmentName = rs.getString("equipmentName");
                    String type = rs.getString("type");
                    int quantity = rs.getInt("quantity");
                    model.addRow(new Object[]{id, equipmentID, equipmentName, type, quantity});
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
                
        } 

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        inventoryTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        inventoryTable.setBackground(new java.awt.Color(255, 255, 255));
        inventoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "No.", "Equipment ID", "Name of Equipment", "Type", "Quantity", "Action"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        inventoryTable.setGridColor(new java.awt.Color(255, 255, 255));
        inventoryTable.setRowHeight(40);
        jScrollPane1.setViewportView(inventoryTable);
        if (inventoryTable.getColumnModel().getColumnCount() > 0) {
            inventoryTable.getColumnModel().getColumn(0).setPreferredWidth(15);
            inventoryTable.getColumnModel().getColumn(4).setResizable(false);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 847, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 490, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new table().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable inventoryTable;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
