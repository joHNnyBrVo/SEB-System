package raven.cell;

public interface TableActionEvent {

    //Inventory Table Action Button
    public void onInventoryEditBtn(int row);
    public void onInventoryDeleteBtn(int row);

    //Borrow Table Action Button
    public void onBorrowEditBtn(int row);
    public void onBorrowDeleteBtn(int row);
    public void onBorrowViewBtn(int row);
    public void onReturnBorrowtBtn(int row);

    //Staff Table Action Button
    public void onActiveBtn(int row);
    public void onDiactiveBtn(int row);
    public void onRemoveBtn(int row);
}
