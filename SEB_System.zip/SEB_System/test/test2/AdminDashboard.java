package test2;

import MainProgram.*;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import java.awt.Image;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import raven.glasspanepopup.GlassPanePopup;
import raven.glasspanepopup.DefaultOption;

public class AdminDashboard extends javax.swing.JFrame {
    
    public AdminDashboard() throws IOException {
        initComponents();
        //Popup Code
        GlassPanePopup.install(this);
        //System Icon
        setIconLogo();
        
        //Instance AppUtilities
        AppUtilities utilities = new AppUtilities();
        
        //Custom fonstyle
        utilities.customFontStyle(headerLabel, "Poppins-Bold.ttf", 20f);
        utilities.customFontStyle(userName, "Poppins-Regular.ttf", 20f);
        
        //Menu fontstyle
        utilities.customFontStyle(dashboardLabel, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(staffLabel, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(equipmentLabel, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(transacLabel, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(gymlogLabel, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(logoutLabel, "Poppins-Regular.ttf", 16f);
        
        this.setTitle("SEB System - Admin");
        this.setLocationRelativeTo(null);
//        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    @SuppressWarnings("unchecked")
    //set icon to java frame
    public final void setIconLogo(){        
        Image iconLogo = new ImageIcon(getClass().getResource("/icons/sports.png")).getImage(); 
        this.setIconImage(iconLogo);
    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        headerLabel = new javax.swing.JLabel();
        menuPanel = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        sidebarPanel = new javax.swing.JPanel();
        profileBox = new MainProgram.RoundedPanel();
        userName = new javax.swing.JLabel();
        lineSeparator = new javax.swing.JSeparator();
        dashboardMenuBtn = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        dashboardLabel = new javax.swing.JLabel();
        staffMenuBtn = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        staffLabel = new javax.swing.JLabel();
        transacMenuBtn = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        transacLabel = new javax.swing.JLabel();
        equipmentMenuBtn = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        equipmentLabel = new javax.swing.JLabel();
        gymlogMenuBtn = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        gymlogLabel = new javax.swing.JLabel();
        logoutMenuBtn = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        logoutLabel = new javax.swing.JLabel();
        contentPanel = new javax.swing.JPanel();
        dashboardPanel = new javax.swing.JPanel();
        roundedPanel3 = new MainProgram.RoundedPanel();
        roundedPanel5 = new MainProgram.RoundedPanel();
        roundedPanel4 = new MainProgram.RoundedPanel();
        roundedPanel6 = new MainProgram.RoundedPanel();
        staffPanel = new javax.swing.JPanel();
        roundedPanel11 = new MainProgram.RoundedPanel();
        roundedPanel12 = new MainProgram.RoundedPanel();
        equipmentPanel = new javax.swing.JPanel();
        roundedPanel1 = new MainProgram.RoundedPanel();
        popupBtn = new MainProgram.Button();
        roundedPanel2 = new MainProgram.RoundedPanel();
        transacPanel = new javax.swing.JPanel();
        roundedPanel7 = new MainProgram.RoundedPanel();
        roundedPanel9 = new MainProgram.RoundedPanel();
        roundedPanel8 = new MainProgram.RoundedPanel();
        roundedPanel10 = new MainProgram.RoundedPanel();
        gymlogPanel = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("adminFrame"); // NOI18N
        setSize(new java.awt.Dimension(1350, 710));
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
        });

        mainPanel.setBackground(new java.awt.Color(255, 255, 255));
        mainPanel.setMinimumSize(new java.awt.Dimension(1350, 710));
        mainPanel.setPreferredSize(new java.awt.Dimension(1350, 705));
        mainPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        headerPanel.setBackground(new java.awt.Color(13, 146, 244));
        headerPanel.setPreferredSize(new java.awt.Dimension(1350, 50));

        headerLabel.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        headerLabel.setForeground(new java.awt.Color(255, 255, 255));
        headerLabel.setText("SPORTS EQUIPMENT BORROWING SYSTEM");

        menuPanel.setBackground(new java.awt.Color(13, 146, 244));
        menuPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuPanelMouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N

        javax.swing.GroupLayout menuPanelLayout = new javax.swing.GroupLayout(menuPanel);
        menuPanel.setLayout(menuPanelLayout);
        menuPanelLayout.setHorizontalGroup(
            menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel7))
        );
        menuPanelLayout.setVerticalGroup(
            menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel7))
        );

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/account.png"))); // NOI18N

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(240, 240, 240));
        jLabel9.setText("Admin");

        javax.swing.GroupLayout headerPanelLayout = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menuPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(headerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 434, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addGap(70, 70, 70))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGroup(headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(headerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(headerLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                            .addComponent(menuPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(headerPanelLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel9)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainPanel.add(headerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 1150, 50));

        sidebarPanel.setBackground(new java.awt.Color(34, 45, 50));
        sidebarPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        profileBox.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout profileBoxLayout = new javax.swing.GroupLayout(profileBox);
        profileBox.setLayout(profileBoxLayout);
        profileBoxLayout.setHorizontalGroup(
            profileBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 80, Short.MAX_VALUE)
        );
        profileBoxLayout.setVerticalGroup(
            profileBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 80, Short.MAX_VALUE)
        );

        sidebarPanel.add(profileBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 80, 80));

        userName.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        userName.setForeground(new java.awt.Color(255, 255, 255));
        userName.setText("ADMIN");
        sidebarPanel.add(userName, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, -1, -1));

        lineSeparator.setBackground(new java.awt.Color(255, 255, 255));
        lineSeparator.setForeground(new java.awt.Color(255, 255, 255));
        sidebarPanel.add(lineSeparator, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 230, 10));

        dashboardMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        dashboardMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dashboardMenuBtnMousePressed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/dashboard.png"))); // NOI18N
        jLabel1.setPreferredSize(new java.awt.Dimension(64, 64));

        dashboardLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        dashboardLabel.setForeground(new java.awt.Color(255, 255, 255));
        dashboardLabel.setText("Dashboard");

        javax.swing.GroupLayout dashboardMenuBtnLayout = new javax.swing.GroupLayout(dashboardMenuBtn);
        dashboardMenuBtn.setLayout(dashboardMenuBtnLayout);
        dashboardMenuBtnLayout.setHorizontalGroup(
            dashboardMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dashboardLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        dashboardMenuBtnLayout.setVerticalGroup(
            dashboardMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dashboardMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dashboardMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(dashboardLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(dashboardMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 230, -1));

        staffMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        staffMenuBtn.setForeground(new java.awt.Color(255, 255, 255));
        staffMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                staffMenuBtnMousePressed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/staff.png"))); // NOI18N

        staffLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        staffLabel.setForeground(new java.awt.Color(255, 255, 255));
        staffLabel.setText("Staff Management ");

        javax.swing.GroupLayout staffMenuBtnLayout = new javax.swing.GroupLayout(staffMenuBtn);
        staffMenuBtn.setLayout(staffMenuBtnLayout);
        staffMenuBtnLayout.setHorizontalGroup(
            staffMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(staffMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(staffLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );
        staffMenuBtnLayout.setVerticalGroup(
            staffMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(staffMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(staffMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(staffLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(staffMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 230, -1));

        transacMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        transacMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                transacMenuBtnMousePressed(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/borrow.png"))); // NOI18N

        transacLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        transacLabel.setForeground(new java.awt.Color(255, 255, 255));
        transacLabel.setText("Borrowing Records");

        javax.swing.GroupLayout transacMenuBtnLayout = new javax.swing.GroupLayout(transacMenuBtn);
        transacMenuBtn.setLayout(transacMenuBtnLayout);
        transacMenuBtnLayout.setHorizontalGroup(
            transacMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transacMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(transacLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                .addContainerGap())
        );
        transacMenuBtnLayout.setVerticalGroup(
            transacMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transacMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(transacMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(transacLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(transacMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 230, 40));

        equipmentMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        equipmentMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                equipmentMenuBtnMousePressed(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/inventory.png"))); // NOI18N

        equipmentLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        equipmentLabel.setForeground(new java.awt.Color(255, 255, 255));
        equipmentLabel.setText("Equipment Inventory");

        javax.swing.GroupLayout equipmentMenuBtnLayout = new javax.swing.GroupLayout(equipmentMenuBtn);
        equipmentMenuBtn.setLayout(equipmentMenuBtnLayout);
        equipmentMenuBtnLayout.setHorizontalGroup(
            equipmentMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(equipmentMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(equipmentLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        equipmentMenuBtnLayout.setVerticalGroup(
            equipmentMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(equipmentMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(equipmentMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(equipmentLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(equipmentMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 230, -1));

        gymlogMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        gymlogMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                gymlogMenuBtnMousePressed(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/gym.png"))); // NOI18N

        gymlogLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        gymlogLabel.setForeground(new java.awt.Color(255, 255, 255));
        gymlogLabel.setText("Gym Log");

        javax.swing.GroupLayout gymlogMenuBtnLayout = new javax.swing.GroupLayout(gymlogMenuBtn);
        gymlogMenuBtn.setLayout(gymlogMenuBtnLayout);
        gymlogMenuBtnLayout.setHorizontalGroup(
            gymlogMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gymlogMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gymlogLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(82, Short.MAX_VALUE))
        );
        gymlogMenuBtnLayout.setVerticalGroup(
            gymlogMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gymlogMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(gymlogMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(gymlogLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(gymlogMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 230, -1));

        logoutMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        logoutMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                logoutMenuBtnMousePressed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logout.png"))); // NOI18N

        logoutLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        logoutLabel.setForeground(new java.awt.Color(255, 255, 255));
        logoutLabel.setText("Logout");

        javax.swing.GroupLayout logoutMenuBtnLayout = new javax.swing.GroupLayout(logoutMenuBtn);
        logoutMenuBtn.setLayout(logoutMenuBtnLayout);
        logoutMenuBtnLayout.setHorizontalGroup(
            logoutMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logoutMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(logoutLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(84, Short.MAX_VALUE))
        );
        logoutMenuBtnLayout.setVerticalGroup(
            logoutMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logoutMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(logoutMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(logoutLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(logoutMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 670, 230, -1));

        mainPanel.add(sidebarPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 710));

        contentPanel.setBackground(new java.awt.Color(255, 255, 255));
        contentPanel.setLayout(new java.awt.CardLayout());

        dashboardPanel.setBackground(new java.awt.Color(255, 255, 255));

        roundedPanel3.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout roundedPanel3Layout = new javax.swing.GroupLayout(roundedPanel3);
        roundedPanel3.setLayout(roundedPanel3Layout);
        roundedPanel3Layout.setHorizontalGroup(
            roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 331, Short.MAX_VALUE)
        );
        roundedPanel3Layout.setVerticalGroup(
            roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 163, Short.MAX_VALUE)
        );

        roundedPanel5.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout roundedPanel5Layout = new javax.swing.GroupLayout(roundedPanel5);
        roundedPanel5.setLayout(roundedPanel5Layout);
        roundedPanel5Layout.setHorizontalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        roundedPanel5Layout.setVerticalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 384, Short.MAX_VALUE)
        );

        roundedPanel4.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout roundedPanel4Layout = new javax.swing.GroupLayout(roundedPanel4);
        roundedPanel4.setLayout(roundedPanel4Layout);
        roundedPanel4Layout.setHorizontalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 331, Short.MAX_VALUE)
        );
        roundedPanel4Layout.setVerticalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 163, Short.MAX_VALUE)
        );

        roundedPanel6.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout roundedPanel6Layout = new javax.swing.GroupLayout(roundedPanel6);
        roundedPanel6.setLayout(roundedPanel6Layout);
        roundedPanel6Layout.setHorizontalGroup(
            roundedPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 331, Short.MAX_VALUE)
        );
        roundedPanel6Layout.setVerticalGroup(
            roundedPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 163, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout dashboardPanelLayout = new javax.swing.GroupLayout(dashboardPanel);
        dashboardPanel.setLayout(dashboardPanelLayout);
        dashboardPanelLayout.setHorizontalGroup(
            dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardPanelLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(roundedPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(dashboardPanelLayout.createSequentialGroup()
                        .addComponent(roundedPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(roundedPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(roundedPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(67, Short.MAX_VALUE))
        );
        dashboardPanelLayout.setVerticalGroup(
            dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardPanelLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(roundedPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(roundedPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(roundedPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addComponent(roundedPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        contentPanel.add(dashboardPanel, "card2");

        staffPanel.setBackground(new java.awt.Color(255, 255, 255));

        roundedPanel11.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout roundedPanel11Layout = new javax.swing.GroupLayout(roundedPanel11);
        roundedPanel11.setLayout(roundedPanel11Layout);
        roundedPanel11Layout.setHorizontalGroup(
            roundedPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1049, Short.MAX_VALUE)
        );
        roundedPanel11Layout.setVerticalGroup(
            roundedPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 56, Short.MAX_VALUE)
        );

        roundedPanel12.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout roundedPanel12Layout = new javax.swing.GroupLayout(roundedPanel12);
        roundedPanel12.setLayout(roundedPanel12Layout);
        roundedPanel12Layout.setHorizontalGroup(
            roundedPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1049, Short.MAX_VALUE)
        );
        roundedPanel12Layout.setVerticalGroup(
            roundedPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 501, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout staffPanelLayout = new javax.swing.GroupLayout(staffPanel);
        staffPanel.setLayout(staffPanelLayout);
        staffPanelLayout.setHorizontalGroup(
            staffPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(staffPanelLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(staffPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(roundedPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(roundedPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        staffPanelLayout.setVerticalGroup(
            staffPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(staffPanelLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(roundedPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(roundedPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        contentPanel.add(staffPanel, "card3");

        equipmentPanel.setBackground(new java.awt.Color(255, 255, 255));
        equipmentPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        roundedPanel1.setBackground(new java.awt.Color(102, 102, 102));

        popupBtn.setForeground(new java.awt.Color(51, 51, 51));
        popupBtn.setText("+ New Item");
        popupBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                popupBtnMouseClicked(evt);
            }
        });
        popupBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                popupBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout roundedPanel1Layout = new javax.swing.GroupLayout(roundedPanel1);
        roundedPanel1.setLayout(roundedPanel1Layout);
        roundedPanel1Layout.setHorizontalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(popupBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(937, Short.MAX_VALUE))
        );
        roundedPanel1Layout.setVerticalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel1Layout.createSequentialGroup()
                .addContainerGap(9, Short.MAX_VALUE)
                .addComponent(popupBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        equipmentPanel.add(roundedPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 1040, 50));

        roundedPanel2.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout roundedPanel2Layout = new javax.swing.GroupLayout(roundedPanel2);
        roundedPanel2.setLayout(roundedPanel2Layout);
        roundedPanel2Layout.setHorizontalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1040, Short.MAX_VALUE)
        );
        roundedPanel2Layout.setVerticalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 450, Short.MAX_VALUE)
        );

        equipmentPanel.add(roundedPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 1040, 450));

        contentPanel.add(equipmentPanel, "card4");

        transacPanel.setBackground(new java.awt.Color(255, 255, 255));

        roundedPanel7.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout roundedPanel9Layout = new javax.swing.GroupLayout(roundedPanel9);
        roundedPanel9.setLayout(roundedPanel9Layout);
        roundedPanel9Layout.setHorizontalGroup(
            roundedPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 331, Short.MAX_VALUE)
        );
        roundedPanel9Layout.setVerticalGroup(
            roundedPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 34, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout roundedPanel7Layout = new javax.swing.GroupLayout(roundedPanel7);
        roundedPanel7.setLayout(roundedPanel7Layout);
        roundedPanel7Layout.setHorizontalGroup(
            roundedPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel7Layout.createSequentialGroup()
                .addContainerGap(674, Short.MAX_VALUE)
                .addComponent(roundedPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        roundedPanel7Layout.setVerticalGroup(
            roundedPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel7Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(roundedPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        roundedPanel8.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout roundedPanel10Layout = new javax.swing.GroupLayout(roundedPanel10);
        roundedPanel10.setLayout(roundedPanel10Layout);
        roundedPanel10Layout.setHorizontalGroup(
            roundedPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1010, Short.MAX_VALUE)
        );
        roundedPanel10Layout.setVerticalGroup(
            roundedPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 310, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout roundedPanel8Layout = new javax.swing.GroupLayout(roundedPanel8);
        roundedPanel8.setLayout(roundedPanel8Layout);
        roundedPanel8Layout.setHorizontalGroup(
            roundedPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel8Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(roundedPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        roundedPanel8Layout.setVerticalGroup(
            roundedPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel8Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(roundedPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout transacPanelLayout = new javax.swing.GroupLayout(transacPanel);
        transacPanel.setLayout(transacPanelLayout);
        transacPanelLayout.setHorizontalGroup(
            transacPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transacPanelLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(transacPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(roundedPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(roundedPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        transacPanelLayout.setVerticalGroup(
            transacPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transacPanelLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(roundedPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(roundedPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(210, Short.MAX_VALUE))
        );

        contentPanel.add(transacPanel, "card5");

        gymlogPanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Gym");

        javax.swing.GroupLayout gymlogPanelLayout = new javax.swing.GroupLayout(gymlogPanel);
        gymlogPanel.setLayout(gymlogPanelLayout);
        gymlogPanelLayout.setHorizontalGroup(
            gymlogPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gymlogPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addContainerGap(1105, Short.MAX_VALUE))
        );
        gymlogPanelLayout.setVerticalGroup(
            gymlogPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gymlogPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addContainerGap(629, Short.MAX_VALUE))
        );

        contentPanel.add(gymlogPanel, "card6");

        mainPanel.add(contentPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 50, 1150, 660));

        getContentPane().add(mainPanel, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    private void dashboardMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboardMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();

        // Hover Function
        utilities.setHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(staffMenuBtn);
        utilities.resetHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(equipmentMenuBtn);
        utilities.resetHoverMenuBtn(gymlogMenuBtn);
        utilities.resetHoverMenuBtn(logoutMenuBtn);

        // Set visibility for panels
        utilities.setTabPanel(dashboardPanel, true);
        utilities.setTabPanel(staffPanel, false);
        utilities.setTabPanel(equipmentPanel, false);
        utilities.setTabPanel(transacPanel, false);
        utilities.setTabPanel(gymlogPanel, false);
    }//GEN-LAST:event_dashboardMenuBtnMousePressed

    private void staffMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_staffMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();

    // Hover Function
        utilities.setHoverMenuBtn(staffMenuBtn);
        utilities.resetHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(equipmentMenuBtn);
        utilities.resetHoverMenuBtn(gymlogMenuBtn);
        utilities.resetHoverMenuBtn(logoutMenuBtn);

        // Set visibility for panels
        utilities.setTabPanel(staffPanel, true);
        utilities.setTabPanel(dashboardPanel, false);
        utilities.setTabPanel(equipmentPanel, false);
        utilities.setTabPanel(transacPanel, false);
        utilities.setTabPanel(gymlogPanel, false);
    }//GEN-LAST:event_staffMenuBtnMousePressed

    private void equipmentMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_equipmentMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();

        // Hover Function
        utilities.setHoverMenuBtn(equipmentMenuBtn);
        utilities.resetHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(staffMenuBtn);
        utilities.resetHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(gymlogMenuBtn);
        utilities.resetHoverMenuBtn(logoutMenuBtn);

        // Set visibility for panels
        utilities.setTabPanel(equipmentPanel, true);
        utilities.setTabPanel(dashboardPanel, false);
        utilities.setTabPanel(staffPanel, false);
        utilities.setTabPanel(transacPanel, false);
        utilities.setTabPanel(gymlogPanel, false);
    }//GEN-LAST:event_equipmentMenuBtnMousePressed

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_formMousePressed

    private void transacMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_transacMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();

        // Hover Function
        utilities.setHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(staffMenuBtn);
        utilities.resetHoverMenuBtn(equipmentMenuBtn);
        utilities.resetHoverMenuBtn(gymlogMenuBtn);
        utilities.resetHoverMenuBtn(logoutMenuBtn);

        // Set visibility for panels
        utilities.setTabPanel(transacPanel, true);
        utilities.setTabPanel(dashboardPanel, false);
        utilities.setTabPanel(staffPanel, false);
        utilities.setTabPanel(equipmentPanel, false);
        utilities.setTabPanel(gymlogPanel, false);
    }//GEN-LAST:event_transacMenuBtnMousePressed

    private void gymlogMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gymlogMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();

        // Hover Function
        utilities.setHoverMenuBtn(gymlogMenuBtn);
        utilities.resetHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(staffMenuBtn);
        utilities.resetHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(equipmentMenuBtn);
        utilities.resetHoverMenuBtn(logoutMenuBtn);

        // Set visibility for panels
        utilities.setTabPanel(gymlogPanel, true);
        utilities.setTabPanel(dashboardPanel, false);
        utilities.setTabPanel(staffPanel, false);
        utilities.setTabPanel(equipmentPanel, false);
        utilities.setTabPanel(transacPanel, false);
    }//GEN-LAST:event_gymlogMenuBtnMousePressed

    private void logoutMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();
        
        // Hover Function
        utilities.setHoverMenuBtn(logoutMenuBtn);
        utilities.resetHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(staffMenuBtn);
        utilities.resetHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(equipmentMenuBtn);
        utilities.resetHoverMenuBtn(gymlogMenuBtn);
        
        int response; 
        response = JOptionPane.showConfirmDialog(null, "Are you sure you want to log out?",  "Logout", JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE );
        if (response == JOptionPane.YES_OPTION){
            System.out.println("Logout Succesfully!");
        }
    }//GEN-LAST:event_logoutMenuBtnMousePressed

    private void menuPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuPanelMouseClicked
     
    }//GEN-LAST:event_menuPanelMouseClicked

    private void popupBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_popupBtnActionPerformed
        try {
            //        Popup popup = new Popup();
//        popup.setVisible(true);
//Popup
//        GlassPanePopup.showPopup(new AddItemPopup());
            GlassPanePopup.showPopup(new AddItemPopup(), new DefaultOption(){
                @Override
                public float opacity(){
                    return 0;
                }
            });
                    } catch (IOException ex) {
                        Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
                    }
        
    }//GEN-LAST:event_popupBtnActionPerformed

    private void popupBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_popupBtnMouseClicked
        
    }//GEN-LAST:event_popupBtnMouseClicked

    //Main Method
    public static void main(String args[]) {
        //Set up flatlaf theme
        FlatMacLightLaf.setup();

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new AdminDashboard().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel contentPanel;
    private javax.swing.JLabel dashboardLabel;
    private javax.swing.JPanel dashboardMenuBtn;
    private javax.swing.JPanel dashboardPanel;
    private javax.swing.JLabel equipmentLabel;
    private javax.swing.JPanel equipmentMenuBtn;
    private javax.swing.JPanel equipmentPanel;
    private javax.swing.JLabel gymlogLabel;
    private javax.swing.JPanel gymlogMenuBtn;
    private javax.swing.JPanel gymlogPanel;
    private javax.swing.JLabel headerLabel;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator lineSeparator;
    private javax.swing.JLabel logoutLabel;
    private javax.swing.JPanel logoutMenuBtn;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel menuPanel;
    private MainProgram.Button popupBtn;
    private MainProgram.RoundedPanel profileBox;
    private MainProgram.RoundedPanel roundedPanel1;
    private MainProgram.RoundedPanel roundedPanel10;
    private MainProgram.RoundedPanel roundedPanel11;
    private MainProgram.RoundedPanel roundedPanel12;
    private MainProgram.RoundedPanel roundedPanel2;
    private MainProgram.RoundedPanel roundedPanel3;
    private MainProgram.RoundedPanel roundedPanel4;
    private MainProgram.RoundedPanel roundedPanel5;
    private MainProgram.RoundedPanel roundedPanel6;
    private MainProgram.RoundedPanel roundedPanel7;
    private MainProgram.RoundedPanel roundedPanel8;
    private MainProgram.RoundedPanel roundedPanel9;
    private javax.swing.JPanel sidebarPanel;
    private javax.swing.JLabel staffLabel;
    private javax.swing.JPanel staffMenuBtn;
    private javax.swing.JPanel staffPanel;
    private javax.swing.JLabel transacLabel;
    private javax.swing.JPanel transacMenuBtn;
    private javax.swing.JPanel transacPanel;
    private javax.swing.JLabel userName;
    // End of variables declaration//GEN-END:variables
}
