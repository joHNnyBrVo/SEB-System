package raven.cell;

import java.awt.Component;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JTable;

public class TableActionCellEditor2 extends DefaultCellEditor {

    private TableActionEvent event;

    public TableActionCellEditor2(TableActionEvent event) {
        super(new JCheckBox());
        this.event = event;
    }

    @Override
    public Component getTableCellEditorComponent(JTable jtable, Object o, boolean bln, int row, int column) {
        try {
            ReturnAction action = new ReturnAction();
            action.initEvent(event, row);
            action.setBackground(jtable.getSelectionBackground());
            return action;
        } catch (IOException ex) {
            Logger.getLogger(TableActionCellEditor2.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
