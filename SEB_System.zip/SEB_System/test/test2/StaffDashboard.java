package test2;

import MainProgram.AppUtilities;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import java.awt.Image;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class StaffDashboard extends javax.swing.JFrame {

    public StaffDashboard() throws IOException {
        initComponents();
        setIconLogo();
        
        //Instance AppUtilities
        AppUtilities utilities = new AppUtilities();
        
        //Sidebar Menu fontstyle
        utilities.customFontStyle(dashboardLabel, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(inventoryLabel, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(transacLabel, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(gymLabel, "Poppins-Regular.ttf", 16f);
        utilities.customFontStyle(logoutLabel, "Poppins-Regular.ttf", 16f);
        
        //Set Title
        this.setTitle("SEB System - Staff");
        this.setLocationRelativeTo(null);
//        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    @SuppressWarnings("unchecked")
    //Set icon logo to java frame
    public final void setIconLogo(){        
        Image iconLogo = new ImageIcon(getClass().getResource("/icons/sports.png")).getImage(); 
        this.setIconImage(iconLogo);
    }   
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        sidebarPanel = new javax.swing.JPanel();
        lineSeparator = new javax.swing.JSeparator();
        dashboardMenuBtn = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        dashboardLabel = new javax.swing.JLabel();
        inventoryMenuBtn = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        inventoryLabel = new javax.swing.JLabel();
        transacMenuBtn = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        transacLabel = new javax.swing.JLabel();
        gymMenuBtn = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        gymLabel = new javax.swing.JLabel();
        logoutMenuBtn = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        logoutLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        profileBox = new MainProgram.RoundedPanel();
        contentPanel = new javax.swing.JPanel();
        dashboardPanel = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        inventoryPanel = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        transacPanel = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        gymPanel = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(1350, 710));

        mainPanel.setBackground(new java.awt.Color(255, 255, 255));
        mainPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        headerPanel.setBackground(new java.awt.Color(13, 146, 244));
        headerPanel.setPreferredSize(new java.awt.Dimension(1375, 50));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/account.png"))); // NOI18N

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(240, 240, 240));
        jLabel13.setText("Staff");

        javax.swing.GroupLayout headerPanelLayout = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 977, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerPanelLayout.createSequentialGroup()
                .addGroup(headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(headerPanelLayout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, headerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );

        mainPanel.add(headerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 1145, -1));

        sidebarPanel.setBackground(new java.awt.Color(34, 45, 50));
        sidebarPanel.setPreferredSize(new java.awt.Dimension(230, 620));
        sidebarPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lineSeparator.setBackground(new java.awt.Color(255, 255, 255));
        lineSeparator.setForeground(new java.awt.Color(255, 255, 255));
        sidebarPanel.add(lineSeparator, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 230, 10));

        dashboardMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        dashboardMenuBtn.setPreferredSize(new java.awt.Dimension(230, 40));
        dashboardMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dashboardMenuBtnMousePressed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/dashboard.png"))); // NOI18N

        dashboardLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        dashboardLabel.setForeground(new java.awt.Color(255, 255, 255));
        dashboardLabel.setText("Dashboard");

        javax.swing.GroupLayout dashboardMenuBtnLayout = new javax.swing.GroupLayout(dashboardMenuBtn);
        dashboardMenuBtn.setLayout(dashboardMenuBtnLayout);
        dashboardMenuBtnLayout.setHorizontalGroup(
            dashboardMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dashboardLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        dashboardMenuBtnLayout.setVerticalGroup(
            dashboardMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dashboardMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(dashboardLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(dashboardMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, -1, -1));

        inventoryMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        inventoryMenuBtn.setPreferredSize(new java.awt.Dimension(230, 40));
        inventoryMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                inventoryMenuBtnMousePressed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/inventory.png"))); // NOI18N

        inventoryLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        inventoryLabel.setForeground(new java.awt.Color(255, 255, 255));
        inventoryLabel.setText("Sports Inventory ");

        javax.swing.GroupLayout inventoryMenuBtnLayout = new javax.swing.GroupLayout(inventoryMenuBtn);
        inventoryMenuBtn.setLayout(inventoryMenuBtnLayout);
        inventoryMenuBtnLayout.setHorizontalGroup(
            inventoryMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inventoryMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(inventoryLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        inventoryMenuBtnLayout.setVerticalGroup(
            inventoryMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inventoryMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(inventoryMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(inventoryLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(inventoryMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 230, -1));

        transacMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        transacMenuBtn.setPreferredSize(new java.awt.Dimension(230, 40));
        transacMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                transacMenuBtnMousePressed(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/borrow.png"))); // NOI18N

        transacLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        transacLabel.setForeground(new java.awt.Color(255, 255, 255));
        transacLabel.setText("Borrowing Transactions");

        javax.swing.GroupLayout transacMenuBtnLayout = new javax.swing.GroupLayout(transacMenuBtn);
        transacMenuBtn.setLayout(transacMenuBtnLayout);
        transacMenuBtnLayout.setHorizontalGroup(
            transacMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transacMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(transacLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                .addContainerGap())
        );
        transacMenuBtnLayout.setVerticalGroup(
            transacMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transacMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(transacMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(transacLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(transacMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 230, -1));

        gymMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        gymMenuBtn.setPreferredSize(new java.awt.Dimension(230, 40));
        gymMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                gymMenuBtnMousePressed(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/gym.png"))); // NOI18N

        gymLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        gymLabel.setForeground(new java.awt.Color(255, 255, 255));
        gymLabel.setText("Gym Check-In/Out");

        javax.swing.GroupLayout gymMenuBtnLayout = new javax.swing.GroupLayout(gymMenuBtn);
        gymMenuBtn.setLayout(gymMenuBtnLayout);
        gymMenuBtnLayout.setHorizontalGroup(
            gymMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gymMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gymLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        gymMenuBtnLayout.setVerticalGroup(
            gymMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gymMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(gymMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(gymLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(gymMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 230, -1));

        logoutMenuBtn.setBackground(new java.awt.Color(34, 45, 50));
        logoutMenuBtn.setPreferredSize(new java.awt.Dimension(230, 40));
        logoutMenuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                logoutMenuBtnMousePressed(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logout.png"))); // NOI18N

        logoutLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        logoutLabel.setForeground(new java.awt.Color(255, 255, 255));
        logoutLabel.setText("Logout");

        javax.swing.GroupLayout logoutMenuBtnLayout = new javax.swing.GroupLayout(logoutMenuBtn);
        logoutMenuBtn.setLayout(logoutMenuBtnLayout);
        logoutMenuBtnLayout.setHorizontalGroup(
            logoutMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logoutMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(logoutLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        logoutMenuBtnLayout.setVerticalGroup(
            logoutMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logoutMenuBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(logoutMenuBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(logoutLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        sidebarPanel.add(logoutMenuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 670, 230, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Staff");
        sidebarPanel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, -1, -1));

        javax.swing.GroupLayout profileBoxLayout = new javax.swing.GroupLayout(profileBox);
        profileBox.setLayout(profileBoxLayout);
        profileBoxLayout.setHorizontalGroup(
            profileBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 70, Short.MAX_VALUE)
        );
        profileBoxLayout.setVerticalGroup(
            profileBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 70, Short.MAX_VALUE)
        );

        sidebarPanel.add(profileBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 70, 70));

        mainPanel.add(sidebarPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 710));

        contentPanel.setBackground(new java.awt.Color(255, 255, 255));
        contentPanel.setPreferredSize(new java.awt.Dimension(1120, 660));
        contentPanel.setLayout(new java.awt.CardLayout());

        dashboardPanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Dashboard");

        javax.swing.GroupLayout dashboardPanelLayout = new javax.swing.GroupLayout(dashboardPanel);
        dashboardPanel.setLayout(dashboardPanelLayout);
        dashboardPanelLayout.setHorizontalGroup(
            dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addContainerGap(1047, Short.MAX_VALUE))
        );
        dashboardPanelLayout.setVerticalGroup(
            dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addContainerGap(629, Short.MAX_VALUE))
        );

        contentPanel.add(dashboardPanel, "card2");

        inventoryPanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Inventory");

        javax.swing.GroupLayout inventoryPanelLayout = new javax.swing.GroupLayout(inventoryPanel);
        inventoryPanel.setLayout(inventoryPanelLayout);
        inventoryPanelLayout.setHorizontalGroup(
            inventoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inventoryPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(1056, Short.MAX_VALUE))
        );
        inventoryPanelLayout.setVerticalGroup(
            inventoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inventoryPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(629, Short.MAX_VALUE))
        );

        contentPanel.add(inventoryPanel, "card3");

        transacPanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Dashboard");

        javax.swing.GroupLayout transacPanelLayout = new javax.swing.GroupLayout(transacPanel);
        transacPanel.setLayout(transacPanelLayout);
        transacPanelLayout.setHorizontalGroup(
            transacPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transacPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addContainerGap(1047, Short.MAX_VALUE))
        );
        transacPanelLayout.setVerticalGroup(
            transacPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transacPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addContainerGap(629, Short.MAX_VALUE))
        );

        contentPanel.add(transacPanel, "card4");

        gymPanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Gym");

        javax.swing.GroupLayout gymPanelLayout = new javax.swing.GroupLayout(gymPanel);
        gymPanel.setLayout(gymPanelLayout);
        gymPanelLayout.setHorizontalGroup(
            gymPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gymPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(1100, Short.MAX_VALUE))
        );
        gymPanelLayout.setVerticalGroup(
            gymPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gymPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(629, Short.MAX_VALUE))
        );

        contentPanel.add(gymPanel, "card5");

        mainPanel.add(contentPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 50, 1145, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dashboardMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboardMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();
        
        // Hover Function 
        utilities.setHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(inventoryMenuBtn);
        utilities.resetHoverMenuBtn(gymMenuBtn);
        utilities.resetHoverMenuBtn(logoutMenuBtn);

        // Set visibility for panels 
        utilities.setTabPanel(dashboardPanel, true);
        utilities.setTabPanel(inventoryPanel, false);
        utilities.setTabPanel(transacPanel, false);
        utilities.setTabPanel(gymPanel, false);
    }//GEN-LAST:event_dashboardMenuBtnMousePressed

    private void inventoryMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inventoryMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();       

        // Hover Function
        utilities.setHoverMenuBtn(inventoryMenuBtn);
        utilities.resetHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(gymMenuBtn);
        utilities.resetHoverMenuBtn(logoutMenuBtn);

        // Set visibility for panels
        utilities.setTabPanel(inventoryPanel, true);
        utilities.setTabPanel(dashboardPanel, false);
        utilities.setTabPanel(transacPanel, false);
        utilities.setTabPanel(gymPanel, false);
    }//GEN-LAST:event_inventoryMenuBtnMousePressed

    private void transacMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_transacMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();        
        
        // Hover Function
        utilities.setHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(inventoryMenuBtn);
        utilities.resetHoverMenuBtn(gymMenuBtn);
        utilities.resetHoverMenuBtn(logoutMenuBtn);

        // Set visibility for panels
        utilities.setTabPanel(transacPanel, true);
        utilities.setTabPanel(dashboardPanel, false);
        utilities.setTabPanel(inventoryPanel, false);
        utilities.setTabPanel(gymPanel, false);
    }//GEN-LAST:event_transacMenuBtnMousePressed

    private void gymMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gymMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();
        
        // Hover Function
        utilities.setHoverMenuBtn(gymMenuBtn);
        utilities.resetHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(inventoryMenuBtn);
        utilities.resetHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(logoutMenuBtn);

        // Set visibility for panels 
        utilities.setTabPanel(gymPanel, true);
        utilities.setTabPanel(dashboardPanel, false);
        utilities.setTabPanel(inventoryPanel, false);
        utilities.setTabPanel(transacPanel, false);
    }//GEN-LAST:event_gymMenuBtnMousePressed

    private void logoutMenuBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMenuBtnMousePressed
        AppUtilities utilities = new AppUtilities();
        
        // Hover Function
        utilities.setHoverMenuBtn(logoutMenuBtn);
        utilities.resetHoverMenuBtn(dashboardMenuBtn);
        utilities.resetHoverMenuBtn(inventoryMenuBtn);
        utilities.resetHoverMenuBtn(transacMenuBtn);
        utilities.resetHoverMenuBtn(gymMenuBtn);
        
        int response; 
        response = JOptionPane.showConfirmDialog(null, "Are you sure you want to log out?",  "Logout", JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE );
        if (response == JOptionPane.YES_OPTION){
            System.out.println("Logout Succesfully!");
        }
    }//GEN-LAST:event_logoutMenuBtnMousePressed

    public static void main(String args[]) {
        //Set up flatlaf theme
        FlatMacLightLaf.setup();

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new StaffDashboard().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(StaffDashboard.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel contentPanel;
    private javax.swing.JLabel dashboardLabel;
    private javax.swing.JPanel dashboardMenuBtn;
    private javax.swing.JPanel dashboardPanel;
    private javax.swing.JLabel gymLabel;
    private javax.swing.JPanel gymMenuBtn;
    private javax.swing.JPanel gymPanel;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel inventoryLabel;
    private javax.swing.JPanel inventoryMenuBtn;
    private javax.swing.JPanel inventoryPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator lineSeparator;
    private javax.swing.JLabel logoutLabel;
    private javax.swing.JPanel logoutMenuBtn;
    private javax.swing.JPanel mainPanel;
    private MainProgram.RoundedPanel profileBox;
    private javax.swing.JPanel sidebarPanel;
    private javax.swing.JLabel transacLabel;
    private javax.swing.JPanel transacMenuBtn;
    private javax.swing.JPanel transacPanel;
    // End of variables declaration//GEN-END:variables
}
