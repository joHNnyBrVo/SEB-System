package ReportGenerator;

import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Image;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import javax.swing.*;
import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ChartPDFExporter {
    
    public static void exportCharts(JPanel graphPanel, JPanel equipmentChartPanel, JPanel overdueChartPanel, JFrame parentFrame) {
        try {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
            String timestamp = now.format(formatter);
            
            String defaultPath = "D:\\Documents\\NetBeansProjects\\SEB_System\\reports\\";
            String defaultFileName = "charts_report_" + timestamp + ".pdf";
            
            File reportsDir = new File(defaultPath);
            if (!reportsDir.exists()) {
                reportsDir.mkdirs();
            }
            
            JFileChooser fileChooser = new JFileChooser(defaultPath);
            fileChooser.setDialogTitle("Save PDF Report");
            fileChooser.setSelectedFile(new File(defaultPath + defaultFileName));
            fileChooser.setFileFilter(new FileNameExtensionFilter("PDF files (*.pdf)", "pdf"));
            
            int userSelection = fileChooser.showSaveDialog(parentFrame);
            
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                if (!fileToSave.getAbsolutePath().toLowerCase().endsWith(".pdf")) {
                    fileToSave = new File(fileToSave.getAbsolutePath() + ".pdf");
                }
                
                if (fileToSave.exists()) {
                    int response = JOptionPane.showConfirmDialog(parentFrame,
                            "The file already exists. Do you want to replace it?",
                            "Confirm Overwrite",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);
                    
                    if (response != JOptionPane.YES_OPTION) {
                        return;
                    }
                }
                
                Document document = new Document();
                PdfWriter.getInstance(document, new FileOutputStream(fileToSave));
                document.open();

                Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 24);
                Font normalFont = FontFactory.getFont(FontFactory.HELVETICA, 12);
                Font subtitleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);

                document.add(new Paragraph("Charts Report", titleFont));
                document.add(new Paragraph("Generated on: " + 
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")), normalFont));
                document.add(new Paragraph("\n"));

                JFreeChart transactionChart = ((ChartPanel)graphPanel.getComponent(0)).getChart();
                File transactionTemp = File.createTempFile("transaction", ".png");
                ChartUtils.saveChartAsPNG(transactionTemp, transactionChart, 800, 500);
                Image transactionImage = Image.getInstance(transactionTemp.getAbsolutePath());
                transactionImage.scaleToFit(500, 300);
                document.add(new Paragraph("Transaction Time Chart", subtitleFont));
                document.add(transactionImage);
                document.add(new Paragraph("\n"));

                JFreeChart equipmentChart = ((ChartPanel)equipmentChartPanel.getComponent(0)).getChart();
                File equipmentTemp = File.createTempFile("equipment", ".png");
                ChartUtils.saveChartAsPNG(equipmentTemp, equipmentChart, 800, 500);
                Image equipmentImage = Image.getInstance(equipmentTemp.getAbsolutePath());
                equipmentImage.scaleToFit(500, 300);
                document.add(new Paragraph("Equipment Usage Chart", subtitleFont));
                document.add(equipmentImage);
                document.add(new Paragraph("\n"));

                JFreeChart overdueChart = ((ChartPanel)overdueChartPanel.getComponent(0)).getChart();
                File overdueTemp = File.createTempFile("overdue", ".png");
                ChartUtils.saveChartAsPNG(overdueTemp, overdueChart, 800, 500);
                Image overdueImage = Image.getInstance(overdueTemp.getAbsolutePath());
                overdueImage.scaleToFit(500, 300);
                document.add(new Paragraph("Overdue Status Chart", subtitleFont));
                document.add(overdueImage);

                document.close();

                transactionTemp.delete();
                equipmentTemp.delete();
                overdueTemp.delete();

                JOptionPane.showMessageDialog(parentFrame,
                    "PDF report has been generated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(parentFrame,
                "Error generating PDF: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}